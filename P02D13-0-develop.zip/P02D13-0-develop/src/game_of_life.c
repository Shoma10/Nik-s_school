#include <stdio.h>
#include <stdlib.h>

const int width = 80;
const int heigth = 25;

int choice(int world[][80], int height, int width) {
int n;
  FILE *file = NULL;   //  fopen("n", "rt");
      printf("Введите номер стартовой карты от 1 до 5\n");

    scanf("%d", &n);
     switch (n) {
      case 1:
        file = fopen("1.txt", "r");
        break;
      case 2:
        file = fopen("2.txt", "r");
        break;
      case 3:
        file = fopen("3.txt", "r");
        break;
      case 4:
        file = fopen("4.txt", "r");
      case 5:
        file = fopen("5.txt", "r");
      default:
        break;

      for (int i = 0; i < height; i++) {
        for (int j = 0; j < width ; j++) {
            fscanf(file, "%d", &world[i][j]);
        }
    }
  }
  return 0;
}
int count_nbr(int grid[][80], int i, int j, int heigth, int width) {
  int count = 0;
    if (i-1 >= 0 && j-1 >= 0) {
    if (grid[i-1][j-1] >= 1)count++;
  }
  if (i-1 >= 0) {
    if (grid[i-1][j] >= 1)count++;
  }
  if (i-1 >= 0 && j+1 < width) {
    if (grid[i-1][j+1] >= 1)count++;
  }
  if (j-1 >= 0) {
    if (grid[i][j-1] >= 1)count++;
  }
  if (j+1 < width) {
    if (grid[i][j+1] >= 1)count++;
  }
  if (i+1 < heigth && j-1 >=0) {
    if (grid[i+1][j-1] >= 1)count++;
  }
  if (i+1 < heigth) {
    if (grid[i+1][j] >= 1)count++;
  }
  if (i+1 < heigth && j+1 < width) {
  if (grid[i+1][j+1] >= 1)count++;
  }
  return count;
}

void output(int world[][80], int height, int  width) {
  for (int i = 0; i < height + 1; i++) {
    for (int j = 0; j < width + 1; j++) {
      printf("%d", world[i][j]);
    }
  }
}

void gen_world(int world[][80], int neighbours[][80], int heigth, int width) {
  for (int i = 0; i < heigth; ++i) {
     printf("\n");
      for (int j = 0; j < width; ++j) {
        if (world[i][j] == 1)
          printf(" *");
        else
          printf(" ");
        neighbours[i][j] = count_nbr(world, i, j, heigth, width);
      }
    }
    for (int i = 0; i < heigth; ++i) {
      for (int j = 0; j < width; ++j) {
        if ( world[i][j] >= 1 ) {
          if (neighbours[i][j] <= 1 || neighbours[i][j] >=4)
            world[i][j] = 0;
        } else {
          if (neighbours[i][j] == 3)
            world[i][j] = 1;
      }
    }
    }
}
int definition_dot_logic(int world[25][80], int i, int j) {
  int count = 0;
  if (world[i][((j - 1 < 0) ? 80 : j)-1] == 1) count++;
  if (world[((i - 1 < 0) ? 25 : i)-1][j] == 1) count++;
  if (world[i][((j + 1 > 79) ? -1 : j)+1] == 1) count++;
  if (world[((i + 1 > 24) ? -1 : i)+1][j] == 1) count++;
  if (world[((i - 1 < 0) ? 25 : i)-1][((j - 1 < 0) ? 80 : j)-1] == 1) count++;
  if (world[((i + 1 > 24) ? -1 : i)+1][((j - 1 < 0) ? 80 : j)-1] == 1) count++;
  if (world[((i + 1 > 24) ? -1 : i)+1][((j + 1 > 79) ? -1 : j)+1] == 1) count++;
  if (world[((i - 1 < 0) ? 25 : i)-1][((j + 1 > 79) ? -1 : j)+1] == 1) count++;
  return count;
}
int main() {
  int width = 80;
  int heigth = 25;
  int world[25][80];
  int neighbours[heigth][width];
  choice(world, heigth, width);
  definition_dot_logic(world, heigth, width);
  for (int c = 0; c < 10000; c++) {
    system("clear");
    gen_world(world, neighbours, heigth, width);
    system("sleep 0.1");
  }
  return 0;
}
