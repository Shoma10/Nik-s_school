// Copyright [22] <ghislain>
#include <stdlib.h>
#include "./s21_string.h"

int s21_strlen(char *str) {
    int i = 0;

    while (*str) {
        i++;
        str++;
    }
    return (i);
}

int s21_strcmp(char *str1, char *str2) {
    int i = 0;
    while (str1[i] == str2[i] && str1[i] != '\0' && str2[i] != '\0')
        i++;
    return (str1[i] - str2[i]);
}

char* s21_strcpy(char *dest, char *src) {
    int d = s21_strlen(dest);
    int s = s21_strlen(src);
    int i = 0;
    if (d >= s) {
        while (i <= s) {
            dest[i] = src[i];
            i++;
        }
    }
    return (dest);
}

char* s21_strcat(char *dest, char *src) {
    int i = 0, j = 0;
    while (dest[i] != '\0')
    i++;
    while (src[j] != '\0')
    dest[i++] = src[j++];
    dest[i] = '\0';
    return (dest);
}

char* s21_strstr(char *str, char *to_find) {
    int i = 0, j;
    if (*to_find == '\0')
    return (str);
    while (str[i] != '\0') {
        j = 0;
        while (str[i + j] == to_find[j]) {
        j++;
        if (to_find[j] == '\0')
        return (&str[i]);
        }
        i++;
    }
    return (NULL);
}
