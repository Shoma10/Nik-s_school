// Copyright [22] <ghislain>
#include <stdio.h>
#include "./s21_string.h"

void s21_strlen_test() {
    char* test_value1 = "School_21";
    char* test_value2 = "Hello";
    char* test_value3 = "iMac";
    printf("%s %s %s\n", test_value1, test_value2, test_value3);
    printf("%d %d %d\n", s21_strlen(test_value1),
    s21_strlen(test_value2), s21_strlen(test_value3));
    if (s21_strlen(test_value1) == 9) printf("SUCCESS\n");
    else
    printf("FAIL\n");
    if (s21_strlen(test_value2) == 5) printf("SUCCESS\n");
    else
    printf("FAIL\n");
    if (s21_strlen(test_value3) == 6) printf("SUCCESS\n");
    else
    printf("FAIL\n");
}

void s21_strcmp_test() {
    char str1[1024] = "School_21";
    char str2[1024] = "School_21";
    char str3[1024] = "Hello";
    char str4[1024] = "Hello";
    char str5[1024] = "iMac";
    char str6[1024] = "IMac";
    printf("%s %s %s %s %s %s\n", str1, str2,
    str3, str4, str5, str6);
    printf("%d %d %d\n", s21_strcmp(str1, str2),
    s21_strcmp(str3, str4), s21_strcmp(str5, str6));
    if (s21_strcmp(str1, str2) == 0) printf("SUCCESS\n");
    else
    printf("FAIL\n");
    if (s21_strcmp(str3, str4) == 0) printf("SUCCESS\n");
    else
    printf("FAIL\n");
    if (s21_strcmp(str5, str6) == 0) printf("SUCCESS\n");
    else
    printf("FAIL\n");
}

int s21_strcpy_test() {
    char string_one[6] = "ABCDE\0";
    char string_two[6] = "FGHKL\0";
    printf("%s\n", string_one);
    printf("%s\n", string_two);
    s21_strcpy(string_one, string_two);
    printf("%s\n", string_one);
    printf("%s\n", string_two);
    printf("%d", s21_strcmp(string_one, string_two));
    printf(s21_strcmp(string_one, string_two) == 0 ? "SUCCESS" : "FAIL");
    return 0;
}

int s21_strcat_test() {
    char string_one[12] = "ABCDE\0";
    char string_two[6] = "FGHKL\0";
    printf("%s\n", string_one);
    printf("%s\n", string_two);
    s21_strcat(string_one, string_two);
    printf("%s\n", string_one);
    printf("%s\n", string_two);
    printf("%d", s21_strcmp(string_one, string_two));
    printf(s21_strcmp(string_one, string_two) == 0 ? "SUCCESS" : "FAIL");
    return 0;
}

int s21_strstr_test() {
    char string_one[6] = "ABCDE\0";
    char string_two[4] = "CDE\0";
    printf("%s\n", string_one);
    printf("%s\n", string_two);
    s21_strstr(string_one, string_two);
    printf("%s\n", string_one);
    printf("%s\n", string_two);
    printf("%d", s21_strcmp(string_one, string_two));
    printf(s21_strcmp(string_one, string_two) == 0 ? "SUCCESS" : "FAIL");
    return 0;
}


int main() {
    #ifdef QUEST1
    s21_strlen_test();
    #endif
    #ifdef QUEST2
    s21_strcmp_test();
    #endif
    #ifdef Quest3
    s21_strcpy_test();
    #endif
    #ifdef Quest4
    s21_strcat_test();
    #endif
    #ifdef Quest6
    s21_strstr_test();
    #endif
}
