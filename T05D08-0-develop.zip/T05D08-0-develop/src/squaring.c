#include <stdio.h>
#define NMAX 10

int input(int *a, int *n);
void output(int *a, int n);
void squaring(int *a, int n);

int main() {
    int n = 0, data[NMAX];
    if (input(data, &n) == 1) {
        printf("n/a\n");
        return 0;
    }
    squaring(data, n);
    output(data, n);
    return 0;
}

int input(int *a, int *n) {
    char c;
    if (scanf("%d%c", n, &c) != 2 || (c != '\n' && c != ' ')) {
        return 1;
    }
    if (*n > 10)
        return 1;
    char b;
    for (int *p = a; p - a < *n; p++) {
        if (scanf("%d%c", p, &b) != 2 || (b != '\n' && b != ' '))
        return 1;
    }
    return (0);
}

void output(int *a, int n) {
    printf("%d", a[0]);
    for (int i = 1; i < n; i++) {
        printf(" %d", a[i]);
    }
    printf("\n");
}

void squaring(int *a, int n) {
    for (int i = 0; i < n; i++) {
        a[i] = a[i]*a[i];
    }
}
