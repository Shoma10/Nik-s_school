#include <stdio.h>
#define NMAX 10

int input(int *a, int *n);
void output(int *a, int n);
int max(int *a, int n);
int min(int *a, int n);
double mean(int *a, int n);
double variance(int *a, int n, double mean);

void output_result(int max_v,
                   int min_v,
                   double mean_v,
                   double variance_v);


int main() {
    int n, data[NMAX];
    if (input(data, &n) == 1) {
        printf("n/a\n");
        return (0);
    }
    double mean_v = mean(data, n);
    output(data, n);
    output_result(max(data, n),
                 min(data, n),
                 mean(data, n),
                  variance(data, n, mean_v));

    return (0);
}

int input(int *a, int *n) {
    char c;
    if (scanf("%d%c", n, &c) != 2 || (c != '\n' && c != ' ')) {
        return 1;
    }
    if (*n > 10)
        return (1);
    char b;
    for (int *p = a; p - a < *n; p++) {
        if (scanf("%d%c", p, &b) != 2 || (b != '\n' && b != ' '))
        return (1);
    }
    return (0);
}

void output(int *a, int n) {
    printf("%d", a[0]);
    for (int i = 1; i < n; i++) {
        printf(" %d", a[i]);
    }
    printf("\n");
}

double mean(int *a, int n) {
    double mean_v = 0.0;
    for (int i = 0; i < n; i++)
    mean_v += a[i];
    mean_v = mean_v / n;
    return mean_v;
}

double variance(int *a, int n, double mean) {
    double variance_v =  0.0;
    for (int i = 0; i < n; i++)
    variance_v += (a[i] - mean) * (a[i] - mean);
    variance_v = variance_v / n;
    return variance_v;
}

int max(int *a, int n) {
    int max_v = 0;
    for (int i = 0; i < n; i++)
    if ((a[i]) > max_v) {
        max_v = a[i];
    }
    return max_v;
}

int min(int *a, int n) {
    int min_v = 1000;
    for (int i = 0; i < n; i++)
    if ((a[i]) < min_v) {
        min_v = a[i];
    }
    return min_v;
}


void output_result(int max_v,
                   int min_v,
                   double mean_v,
                   double variance_v) {
                       printf("%d, %d, %.6f, %.6f", max_v, min_v, mean_v, variance_v);
}
