/*
    Search module for the desired value from data array.

    Returned value must be:
        - "even"
        - ">= mean"
        - "<= mean + 3 * sqrt(variance)"
        - "!= 0"

        OR

        0
*/

#include <stdio.h>
#define NMAX 30

int input(int *a, int *n);
void output(int *a, int n);
int even(int *a, int n);
int mean(int *a, int n);
int variance(int *a, int n, double mean);
void output_result();

int main() {
    int n, data[NMAX];
    if (input(data, &n) == 1) {
        printf("n/a\n");
        return 0;
    }
    int mean_v = mean(data, n);
    output(data, n);
    output_result(even(data, n),
                mean(data, n),
                variance(data, n));

    return 0;
}

int input(int *a, int *n) {
    char c;
    if (scanf("%d%c", n, &c) != 2 || (c != '\n' && c != ' ')) {
        return 1;
    }
    if (*n > 30)
        return (1);
    char b;
    for (int *p = a; p - a < *n; p++) {
        if (scanf("%d%c", p, &b) != 2 || (b != '\n' && b != ' '))
        return (1);
    }
    return (0);
}

void output(int *a, int n) {
    printf("%d", a[0]);
    for (int i = 1; i < n; i++) {
        printf(" %d", a[i]);
    }
    printf("\n");
}

int even(int *a, int n) {
    for (int i = 0; i < n; i++)
    i%2 == 0;
    return even;
}

int mean(int *a, int n) {
    int mean_v = 0;
    for (int i = 0; i < n; i++)
    mean_v += a[i];
    mean_v = mean_v / n;
    return mean_v;
}

int variance(int *a, int n, double mean) {
    int variance_v =  0.0;
    for (int i = 0; i < n; i++)
    variance_v += (a[i] - mean) * (a[i] - mean);
    variance_v = variance_v / n;
    return variance_v;
}

void output_result() {
    int t;
    if (even >= mean <= ((mean + 3 * variance) != 0)) {
        printf("%d", t);
        } else {
            printf("0");
        }
}
