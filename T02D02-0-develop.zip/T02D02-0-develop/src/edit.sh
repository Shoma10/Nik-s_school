#!/bin/bash

# Взять название файла
read -p "Введите название файла: " filename

# Взять строку поиска
read -p "Введите строку поиска: " search

# Взять строку замены
read -p "Введите строку замены: " replace

if [[ $search != "" && $replace != "" ]]; then
	sed -i '' "s/$search/$replace/g" $filename
	size=$(wc -c $filename | awk '{print $1}')
	date=$(date -r "$filename" "+%y-%m-%d %H:%M")
	sum=$(shasum -a 256 "$filename" | awk '{print $1}')
	echo "$filename - $size - $date - $sum - sha256" >> files.log
else
	echo "Нет такого файла"
fi

