# **************************************************************************** #
#                                                                              #
#                                                         :::      ::::::::    #
#    log_analyzer.sh                                    :+:      :+:    :+:    #
#                                                     +:+ +:+         +:+      #
#    By: ghislain <marvin@42.fr>                    +#+  +:+       +#+         #
#                                                 +#+#+#+#+#+   +#+            #
#    Created: 2022/03/16 15:53:12 by ghislain          #+#    #+#              #
#    Updated: 2022/03/16 18:22:22 by ghislain         ###   ########.fr        #
#                                                                              #
# **************************************************************************** #

#!/bin/bash

#Написать исходный файл

read -p "Введите файл для обработки: " filename
if [[ -e $filename && -s $filename ]]; then
	
	sum=`wc -l $filename | awk '{print $1}'`
	uniq=`cut -d " " -f 1 $filename | sort -u | wc -l`
	sha=`cut -d " " -f 8 $filename | sort -u | wc -l`
	echo "$sum" $uniq"" $sha""

else
	echo "Файл пустой!"
fi
