1. mkdir main_key
2. cd key
3. mv *.key ../main_key
4. rm *
yes
5. cd ../main_key
6. mv *.key ../key
7. rm -rf main_key
8. sh unifier.sh
