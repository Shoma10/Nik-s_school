mv door_management_fi door_management_files
mkdir door_{logs,map,configuration}
mv *.conf door_configuration
mv *.log door_logs
mv door_map_1.1 door_map

