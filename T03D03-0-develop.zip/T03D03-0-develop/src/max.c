/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   max.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ghislain <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/17 10:59:57 by ghislain          #+#    #+#             */
/*   Updated: 2022/03/17 22:16:17 by ghislain         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int max(int a, int b);

int main(){
	int x, y;
	scanf("%d%d", &x, &y);
	int z = max(x, y);
	printf("%d\n", z);
}
int max(int a, int b)
{
	int m = a;
	if (b >a)
		m = b;
	return (m);
}
