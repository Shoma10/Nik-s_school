/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   important_function.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ghislain <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/17 21:25:34 by ghislain          #+#    #+#             */
/*   Updated: 2022/03/17 22:18:05 by ghislain         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <math.h>

int	main(){
	 float x;
	  if (scanf("%f", &x) == 1)
{
	float function = 7e-3 * powf(x, 4) + ((22.8 * powf(x, (1/3)) - 1e3) * x + 3) / (x * x / 2) - x * powf((10 + x), (2/x)) - 1.01;
		printf("%.1f\n", function);
	return (0);
} else {
	printf("n/a\n");
	return (0);
}
}
