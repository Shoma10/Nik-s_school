/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   named_hello.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ghislain <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/16 21:53:31 by ghislain          #+#    #+#             */
/*   Updated: 2022/03/17 22:18:34 by ghislain         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	main(void){
	int age;
	printf("What is your name? ");
	scanf("%d", &age);

	char* a;
	char* b;
	a = "Hello";
	b = "!";
	printf("%s, %d%s\n", a, age, b);
	return (0);
}
