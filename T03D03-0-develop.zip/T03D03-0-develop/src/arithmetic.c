/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   arithmetic.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ghislain <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/16 23:28:46 by ghislain          #+#    #+#             */
/*   Updated: 2022/03/17 22:17:22 by ghislain         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	main(){
	int a;
	int b;
	char c;
	printf("Введите два целых числа: ");
	if (scanf("%d %d%c", &a, &b, &c) != 3 || (int)c != '\n')
	{
		printf("n/a\n");
		return (0);
	}
	int add;
	int sub;
	int mul;
	int div;

	if (b != 0)
	{
		add = a+b;
		sub = a-b;
		mul = a*b;
		div = a/b;
		printf("%d %d %d %d\n", add, sub, mul, div);
	} else {
		add = a+b;
		sub = a-b;
		mul = a*b;
		printf("%d %d %d n/a\n", add, sub, mul);
	}
	return (0);
}
