#include <stdio.h>
#include <math.h>
#define NMAX 10
#define TRUE 1
#define FALSE 0
/*------------------------------------
	Здравствуй, человек!
	Чтобы получить ключ 
	поработай с комментариями.
-------------------------------------*/
void input(int *buffer, int *length);
void output(int *buffer, int *length);
int sum_numbers(int *buffer, int length);
int find_numbers(int* buffer, int *length, int number);
int find_num(int *buffer, int cout, int number, int *length);

/*------------------------------------
	Функция получает массив данных 
	через stdin.
	Выдает в stdout особую сумму
	и сформированный массив 
	специальных элементов
	(выбранных с помощью найденной суммы):
	это и будет частью ключа
-------------------------------------*/
int main() {
    int n, data[NMAX], number, cout1 = 0, numbers1;
    input(data, &n);
    number = sum_numbers(data, n);
    printf("%d\n", number);
    cout1 = find_numbers(data, &n, number);
    numbers1 = find_num(data, cout1, number, &n);
    output(&numbers1, &n);
}

/*------------------------------------
	Функция должна находить
	сумму четных элементов 
	с 0-й позиции.
-------------------------------------*/
int sum_numbers(int *buffer, int length) {
    int sum = 0;
    for (int i = 0; i < length; i++) {
           if (buffer[i] % 2 == 0) {
           sum = sum + buffer[i];
        }
    }
    return sum;
}

/*------------------------------------
	Функция должна находить
	все элементы, на которые нацело
	делится переданное число и
	записывает их в выходной массив.
-------------------------------------*/
int find_numbers(int* buffer, int *length, int number) {
    int cout = 0;
        for (int *p = buffer; p - buffer < *length; p++) {
        if (number % *p == 0) {
            cout++;
    }
}
return cout;
}
void input(int *buffer, int *length) {
    char ent;
    int cout = 0;
    if (((scanf("%d%c", length, &ent) != 2) || (ent != '\n')) || (*length > 10) || (length == 0)) {
        printf("n/a\n");
    } else {
        for (int *p = buffer; p - buffer < *length; p++) {
          cout++;
            if ((scanf("%d%c", p, &ent) != 2 || ent != '\n') &&
                ((ent != ' ') || cout == *length)) {
                printf("n/a\n");
            }
        }
    }
}
int find_num(int *buffer, int cout, int number, int *length) {
    int numbers[cout];
for (int *p = buffer; p - buffer < *length; p++) {
        for (int *p1 = numbers; p1 - numbers < cout; p1++) {
            if (number % *p == 0) {
                *p1 = *p;
            }
        }
    }
    return numbers[cout];
}

void output(int *buffer, int *length) {
    printf("%d", *buffer);
        for (int *p = buffer + 1; p - buffer < *length; p++) {
            printf(" %d", *p);
        }
        printf("\n");
}
