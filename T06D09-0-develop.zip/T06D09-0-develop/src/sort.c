#include <stdio.h>
#define NMAX 10

int input(int *a, int n);
void sort(int a[10], int n);
void output(int *a, int n);

int main() {
    int n = 10, data[NMAX];
    int flag = 1;
    if (input(data, n) == flag) {
        printf("n/a\n");
    } else {
    sort(data, n);
    output(data, n);
    return 0;
    }
}

int input(int *a, int n) {
    int flag = 0;
    char c;
    for (int *p = a; p - a < n; ++p) {
        if (scanf("%d%c", p, &c) != 2 || (c != '\n' && c != ' ')) {
            flag = 1;
        }
        if (n > 10 || n < 10) {
            flag = 1;
        }
    }
    return flag;
}

void sort(int a[], int n) {
    int temp;
    for (int i = 0; i < n - 1; ++i) {
        for (int j = 0; j < n - i - 1; j++) {
            if ((a[j]) > a[j+1]) {
                temp = a[j];
                a[j] = a[j+1];
                a[j+1] = temp;
            }
        }
    }
}

void output(int *a, int n) {
    for (int *p = a; p - a < n; p++) {
        printf(" %d", *p);
    }
    printf("\n");
}
