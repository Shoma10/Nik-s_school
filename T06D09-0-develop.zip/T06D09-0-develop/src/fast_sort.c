#include <stdio.h>
#define NMAX 10

int input(int *a, int n);
void sort(int a[10], int n);
void siftDown(int *a, int n, int j);
void heapSort(int *a, int n);
void output(int *a, int n);

int main() {
    int n = 10, data[NMAX], j = 0;
    int flag = 1;
    if (input(data, n) == flag) {
        printf("n/a\n");
    } else {
    sort(data, n);
    output(data, n);
    siftDown(data, n, j);
    heapSort(data, n);
    output(data, n);
    return 0;
    }
}

int input(int *a, int n) {
    int flag = 0;
    char c;
    for (int *p = a; p - a < n; ++p) {
        if (scanf("%d%c", p, &c) != 2 || (c != '\n' && c != ' ')) {
            flag = 1;
        }
        if (n > 10 || n < 10) {
            flag = 1;
        }
    }
    return flag;
}

void sort(int a[], int n) {
    int temp;
    for (int i = 0; i < n - 1; ++i) {
        for (int j = 0; j < n - i - 1; j++) {
            if ((a[j]) > a[j+1]) {
                temp = a[j];
                a[j] = a[j+1];
                a[j+1] = temp;
            }
        }
    }
}

void siftDown(int *a, int n, int j) {
    int maxChild, temp;
    int done = 0;
    while ((n * 2 <= j) && (!done)) {
        if (n *2 == j)
        maxChild = n * 2;
        else if (a[n * 2] > a[n * 2 +1])
        maxChild = n * 2;
        else
        maxChild = n * 2 + 1;
        if (a[n] < a[maxChild]) {
            temp = a[n];
            a[n] = a[maxChild];
            a[maxChild] = temp;
            n = maxChild;
            } else {
                done = 1;
            }
    }
}

void heapSort(int *a, int n) {
    int temp, i;
    for (int i = (n / 2); i >= 0; i--)
    siftDown(a, i, n - 1);
    for (i = n - 1; i >= 1; i--) {
        temp = a[0];
        a[0] = a[i];
        a[i] = temp;
        siftDown(a, 0, i -1);
    }
}

void output(int *a, int n) {
    for (int *p = a; p - a < n; p++) {
        printf(" %d", *p);
    }
    printf("\n");
}
