#lqfoxgh "p2.k"


yrlg p2_i1()
{
    sulqwi("WHVW P2");
}

