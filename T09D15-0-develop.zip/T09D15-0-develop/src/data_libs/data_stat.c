// Copyright [33] <ghislain>
double max(double *data, int n) {
    double max_value = *data;
    for (int i = 0; i < n; i++)
    if ((data[i]) > max_value) {
        max_value = data[i];
    }
    return max_value;
}

double min(double *data, int n) {
    double min_value = *data;
    for (int i = 0; i < n; i++)
    if ((data[i]) < min_value) {
        min_value = data[i];
    }
    return min_value;
}

double mean(double *data, int n) {
    int mean_v = 0;
    for (int i = 0; i < n; i++)
    mean_v += data[i];
    mean_v = mean_v / n;
    return mean_v;
}

double variance(double *data, int n, double mean) {
    double variance_v =  0.0;
    for (int i = 0; i < n; i++)
    variance_v += (data[i] - mean) * (data[i] - mean);
    variance_v = variance_v / n;
    return variance_v;
}
