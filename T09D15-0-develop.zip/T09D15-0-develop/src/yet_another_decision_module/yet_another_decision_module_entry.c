// Copyright [33] <ghislain>
#include <stdlib.h>
#include <stdio.h>
#include "./decision.h"
#include "../data_libs/data_io.h"

int main() {
    double *data = 0;
    int n = 0;
    if (scanf("%d", &n) != 1) {
        printf("n/a");
        exit(0);
    }
    data = malloc((n) * sizeof(double));
    input(data, n);
    if (make_decision(data, n)) {
        printf("YES");
    } else {
        printf("NO");
    }
    free(data);
    return 0;
}
