#include <stdio.h>
const int width = 80;
const int height = 25;
int x1 = 3, x2 = 77, y1 = height/2,
y2 = height/2, ballx = 5, bally = height/2,
speedx = 1, speedy = 0, karet1 = 0, karet2 = 0,
score1 = 0, score2 = 0;
char c;
typedef enum {UP1, DOWN1, UP2, DOWN2, STOP} eDir;
eDir dir;

void clear() {
    printf("\33[0d\33[2j");
}

void map() {
    printf("\n");
    for (int i =0; i < width; i++)
    printf("-");
    printf("\n");

    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) {
            if (j ==0 || j == width - 1 || j == 40) {
                printf("|");
            } else if (i == y1 && j == x1) {
            printf("]");
            } else if (i == y1+1 && j == x1) {
                printf("]");
            } else if (i == y1+2 && j == x1) {
                printf("]");
            } else if (i == y2 && j == x2) {
                printf("[");
            } else if (i == y2+1 && j == x2) {
                printf("[");
            } else if (i == y2+2 && j == x2) {
                printf("[");
            } else if (i == bally && j == ballx) {
                printf("o");
            } else {
                printf(" ");
            }
        }
    printf("\n");
    }
    for (int i =0; i < width; i++)
    printf("-");
    printf("\n");
}

void input() {
    switch (getchar()) {
    case 'a':
        dir = UP1;
        break;
    case 'z':
        dir = DOWN1;
        break;
    case 'k':
        dir = UP2;
        break;
    case 'm':
        dir = DOWN2;
        break;
    case '\n':
        break;
    case 'q':
        c = 'q';
        break;
    case ' ':
        dir = STOP;
        break;
    }
}


void engine() {
int karety1 = y1, karety2 = y2;
switch (dir) {
case UP1:
    y1--;
    karet1 = -1;
    karety1 = y1;
    break;
case DOWN1:
    y1++;
    karet1 = 1;
    karety1 = y1;
    break;
case UP2:
    y2--;
    karet2 = -1;
    karety2 = y2;
    break;
case DOWN2:
    y2++;
    karet2 = 1;
    karety2 = y2;
    break;
case STOP:
    karety1 = y1;
    karety2 = y2;
    karet1 = 0;
    karet2 = 0;
    break;
default:
    printf("Некоректный ввод");
    break;
}


    if (y1 == -1) {
        y1++;
    } else if (y2 == -1) {
        y2++;
    } else if (y1 == 23) {
        y1--;
    } else if (y2 == 23) {
        y2--;
    }

    if (speedx > 0) {
        ballx++;
    } else if (speedx < 0) {
        ballx--;
    }

    if (((ballx == x1+1) && (bally == y1))
        || ((ballx == x1+1) && (bally ==y1+1))
        || ((ballx == x1+1) && (bally == y1+2))) {
            speedx = 1;
    } else if (((ballx == x2-1) && (bally == y2))
        || ((ballx == x2-1) && (bally == y2+1))
        || ((ballx == x2-1) && (bally == y2+2))) {
            speedx = -1;
        }
    if (ballx >=79) {
        ballx = 6;
        bally = y1;
        speedx = 1;
        speedy = 0;
        score1++;
        printf("Игрок 1: %d  Игрок 2: %d", score1, score2);
    } else if (ballx <=0) {
        ballx = 73;
        bally = y2;
        speedx = -1;
        speedy = 0;
        score2++;
        printf("Игрок 1: %d  Игрок 2: %d", score1, score2);
    }
    if ((karet1 == 1) && (ballx == x1+1)) {
        speedy = 1;
    } else if ((karet1 == -1) && (ballx == x1+1)) {
        speedy = -1;
    }

    if ((karet2 == 1) && (ballx == x2-1)) {
        speedy = 1;
    } else if ((karet2 == -1) && (ballx == x2-1)) {
        speedy = -1;
    }

    if (bally == 0) {
        speedy = 1;
    } else if (bally == 24) {
        speedy = -1;
    }

    if (speedy > 0) {
        bally++;
    } else if (speedy < 0) {
        bally--;
    }
}

int main()  {
    while (1) {
        engine();
        clear();
        printf(" ");
        map();
        input();
    if (score1 >= 21) {
        printf("Первый игрок победил\n");
        break;
    } else if (score2 >= 21) {
        printf("Второй игрок победил\n");
        break;
    }
    if (c == 'q') {
            break;
        }
    }
    if (c == 'x') {
        return (0);
    }
    return (0);
}
