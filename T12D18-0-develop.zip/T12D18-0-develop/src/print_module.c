#include <stdio.h>
#include <time.h>

#include "./print_module.h"

int print_char(char ch) {
    return putchar(ch);
}

void print_log(char(*print) (char), char* massage) {
    time_t timer;
    struct tm* a;
    char str[300];
    timer = time(NULL);
    a = localtime(&timer);
    strftime(str, 300, "%H:%M:%S", a);
    printf("%s ", Log_prefix);
    for (int i = 0; str[i] != '\0'; i++)
    printf("%c", str[i]);
    print(' ');
    printf("%s", massage);
}
