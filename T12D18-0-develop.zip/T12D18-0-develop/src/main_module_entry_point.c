#include <stdio.h>

#include "./print_module.h"
//#include "documentation_module.h"

int main() {
    print_log(print_char, Module_load_successb);
    
    //availability_mask = check_available_documentation_module(validate, Documents_count, Documents);

    // Output availability for each document....
	
    return 0;
}
